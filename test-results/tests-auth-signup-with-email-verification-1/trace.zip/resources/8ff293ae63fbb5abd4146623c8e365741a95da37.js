(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__03c33ny._.css","static/chunks/099o_next_0h6ejga._.js","static/chunks/13sf_tailwind-merge_dist_lib_0yk1142._.js","static/chunks/00sw__pnpm_04lnptt._.js","static/chunks/Documents_playwright-testing_next-auth-example_01~bph5._.js"],
    source: "dynamic"
});

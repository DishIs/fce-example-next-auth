(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_00b7117._.js","static/chunks/099o_next_dist_compiled_next-devtools_index_0kvwhju.js","static/chunks/099o_next_dist_compiled_react-dom_0yzj-_3._.js","static/chunks/099o_next_dist_compiled_react-server-dom-turbopack_0wter7g._.js","static/chunks/099o_next_dist_compiled_0wniy-8._.js","static/chunks/099o_next_dist_client_07vyq8u._.js","static/chunks/099o_next_dist_06~-20q._.js","static/chunks/0.34_@swc_helpers_cjs_0.0qsw-._.js"],
    source: "entry"
});
